﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using P110_CoreTravelo.DAL;
using P110_CoreTravelo.Models;

namespace P110_CoreTravelo.Areas.TraveloAdmin.Controllers
{
    [Area("TraveloAdmin")]
    public class SlidersController : Controller
    {
        private readonly TraveloDbContext _context;

        public SlidersController(TraveloDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.Sliders);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            Slider slider = await _context.Sliders.FindAsync(id);

            if(slider == null) return NotFound();

            return View(slider);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Slider slider) //model binding
        {
            //if(ModelState["Image"].ValidationState != ModelValidationState.Valid)
            
            //manual
            if(slider.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected");
                return View();
            }

            if(!(slider.Photo.ContentType.Contains("image/") && slider.Photo.ContentType != "image/gif"))
            {
                ModelState.AddModelError("Photo", "Photo type is not valid");
                return View();
            }

            if(slider.Photo.Length/1024/1024 > 2)
            {
                ModelState.AddModelError("Photo", "Photo size should be less than 2 mb");
                return View();
            }

            return Content("duzgundur");
        }
    }
}